import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const calculatorSlugs = new Set(['swp-calculator','ssy-calculator','rule-of-72-calculator','rent-vs-buy-calculator','fire-calculator','budget-calculator','break-even-calculator','cost-of-delay-sip-calculator','sip-calculator','compound-interest-calculator','mortgage-emi-calculator','roi-calculator','simple-interest-calculator','retirement-calculator','salary-to-hourly-calculator','profit-margin-calculator','fixed-deposit-calculator','recurring-deposit-calculator','lumpsum-calculator','cagr-calculator','car-loan-calculator','personal-loan-calculator','debt-payoff-calculator','inflation-calculator','net-worth-calculator','overtime-pay-calculator','freelance-rate-calculator','income-tax-planner','home-loan-emi-calculator','currency-converter','flat-cost-calculator','loan-emi-calculator','capital-gain-calculator','lumpsum-sip-calculator','loan-against-property-calculator','home-loan-eligibility-calculator','silver-jewelry-calculator','advanced-home-loan-eligibility-calculator','consumer-durable-loan-calculator','gold-jewelry-calculator','loan-prepayment-vs-sip-calculator','loan-to-value-ltv-calculator','stamp-duty-calculator','property-calculator','loan-interest-calculator','ppf-calculator','epf-calculator','gst-calculator','emergency-fund-calculator','credit-card-payoff-calculator','step-up-sip-calculator','sip-goal-calculator','gratuity-calculator','hra-exemption-calculator','nps-calculator']);
const errors = [];
const warnings = [];
const htmlFiles = [];
const publicUrl = 'https://wealtharrays.com/';

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.') && entry.name !== '.well-known') continue;
    if (entry.name === 'node_modules') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.name.endsWith('.html')) htmlFiles.push(full);
  }
}
walk(root);

const read = file => fs.readFileSync(file, 'utf8');
const rel = file => path.relative(root, file).replaceAll(path.sep, '/') || 'index.html';
const attr = (html, name, value) => {
  const re = new RegExp(`<meta[^>]+${name}=["']${value}["'][^>]+content=["']([^"']*)["']|<meta[^>]+content=["']([^"']*)["'][^>]+${name}=["']${value}["']`, 'i');
  const m = html.match(re);
  return (m?.[1] || m?.[2] || '').trim();
};
const canonical = html => html.match(/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']/i)?.[1]?.trim() || '';
const title = html => html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || '';
const h1Count = html => (html.match(/<h1\b/gi) || []).length;
const robots = html => attr(html, 'name', 'robots');
const indexable = html => !/noindex/i.test(robots(html));
const canonicalHost = url => url.startsWith(publicUrl);

function repositoryFileForUrl(url) {
  const pathname = new URL(url).pathname.replace(/^\//, '');
  const candidates = [pathname || 'index.html'];
  if (pathname && pathname.endsWith('/')) candidates.unshift(path.join(pathname, 'index.html'));
  else if (pathname && !path.extname(pathname)) candidates.push(`${pathname}.html`, path.join(pathname, 'index.html'));
  for (const candidate of candidates) {
    const target = path.join(root, candidate);
    if (fs.existsSync(target) && fs.statSync(target).isFile()) return target;
  }
  return null;
}

const seenTitles = new Map();
const seenDescriptions = new Map();
const pageByCanonical = new Map();
for (const file of htmlFiles) {
  const html = read(file);
  const name = rel(file);
  const t = title(html);
  const d = attr(html, 'name', 'description');
  const c = canonical(html);
  const isIndexable = indexable(html);
  const canonicalKey = c || `file:${name}`;

  if (isIndexable) {
    if (!t) errors.push(`${name}: missing title`);
    if (!d) errors.push(`${name}: missing meta description`);
    if (!c) errors.push(`${name}: indexable page missing canonical`);
    if (c && !canonicalHost(c)) errors.push(`${name}: canonical is outside wealtharrays.com`);
    if (h1Count(html) !== 1) errors.push(`${name}: expected exactly one H1, found ${h1Count(html)}`);
    const pages = pageByCanonical.get(canonicalKey) || [];
    pages.push(name); pageByCanonical.set(canonicalKey, pages);
  }

  if (isIndexable && t) {
    const list = seenTitles.get(t) || [];
    list.push({ name, canonical: canonicalKey }); seenTitles.set(t, list);
  }
  if (isIndexable && d) {
    const list = seenDescriptions.get(d) || [];
    list.push({ name, canonical: canonicalKey }); seenDescriptions.set(d, list);
  }
  if (/smart\.js/i.test(html)) errors.push(`${name}: retired smart.js reference found`);
}

for (const [value, pages] of seenTitles) {
  const canonicalGroups = new Set(pages.map(p => p.canonical));
  if (canonicalGroups.size > 1) errors.push(`Duplicate title across canonical pages: ${pages.map(p => p.name).join(', ')}`);
}
for (const [value, pages] of seenDescriptions) {
  const canonicalGroups = new Set(pages.map(p => p.canonical));
  if (canonicalGroups.size > 1) warnings.push(`Duplicate meta description across canonical pages: ${pages.map(p => p.name).join(', ')}`);
}

const sitemapPath = path.join(root, 'sitemap.xml');
const robotsPath = path.join(root, 'robots.txt');
const headersPath = path.join(root, '_headers');
if (!fs.existsSync(sitemapPath)) errors.push('sitemap.xml missing');
if (!fs.existsSync(robotsPath)) errors.push('robots.txt missing');
if (!fs.existsSync(headersPath)) errors.push('_headers missing');

let sitemapLocs = [];
if (fs.existsSync(sitemapPath)) {
  const sitemap = read(sitemapPath);
  sitemapLocs = [...sitemap.matchAll(/<loc>([^<]+)<\/loc>/g)].map(m => m[1].trim());
  if (!sitemapLocs.includes(publicUrl)) errors.push('sitemap does not contain canonical homepage');
  const seen = new Set();
  for (const url of sitemapLocs) {
    if (seen.has(url)) errors.push(`Duplicate sitemap URL: ${url}`);
    seen.add(url);
    if (!canonicalHost(url)) errors.push(`Sitemap URL outside canonical host: ${url}`);
    const target = repositoryFileForUrl(url);
    if (!target) errors.push(`Sitemap URL has no repository file/route: ${url}`);
    else if (!indexable(read(target))) errors.push(`Sitemap contains noindex page: ${url}`);
  }
  if (sitemapLocs.length < 20) warnings.push(`Sitemap has only ${sitemapLocs.length} URLs; verify intentional coverage.`);
}

if (fs.existsSync(robotsPath)) {
  const robotsTxt = read(robotsPath);
  if (!/^User-agent:\s*\*/mi.test(robotsTxt)) errors.push('robots.txt missing wildcard user-agent');
  if (!/Sitemap:\s*https:\/\/wealtharrays\.com\/sitemap\.xml/i.test(robotsTxt)) errors.push('robots.txt missing canonical sitemap directive');
}

if (fs.existsSync(headersPath)) {
  const headers = read(headersPath);
  for (const required of ['Strict-Transport-Security:', 'Content-Security-Policy:', 'X-Content-Type-Options:', 'Referrer-Policy:', 'Permissions-Policy:']) {
    if (!headers.includes(required)) errors.push(`_headers missing ${required}`);
  }
}

for (const requiredFile of ['about.html', 'contact.html', 'privacy.html', 'terms.html', 'disclaimer.html', 'methodology.html', 'editorial-policy.html', 'advertising-policy.html', '404.html', 'og-card.svg']) {
  if (!fs.existsSync(path.join(root, requiredFile))) errors.push(`Production trust/UX asset missing: ${requiredFile}`);
}

const methodologyPath = path.join(root, 'methodology.html');
if (fs.existsSync(methodologyPath)) {
  const methodology = read(methodologyPath);
  const referenceRows = [...methodology.matchAll(/<tr>\s*<td><a href=["']\/([^/"']+)\//g)].map(m => m[1]);
  if (referenceRows.length !== 55) errors.push(`Methodology reference must contain 55 calculator rows; found ${referenceRows.length}`);
  for (const slug of calculatorSlugs) {
    if (!referenceRows.includes(slug)) errors.push(`Methodology reference missing calculator: ${slug}`);
  }
}
for (const file of htmlFiles) {
  const html = read(file);
  const ogImage = attr(html, 'property', 'og:image');
  const ogType = attr(html, 'property', 'og:image:type');
  if (ogImage && ogImage.endsWith('/og-card.svg') && ogType && ogType !== 'image/svg+xml') {
    errors.push(`${rel(file)}: Open Graph image MIME type does not match SVG asset`);
  }
}

const articleSourceRequirements = [
  ['articles/how-to-use-a-salary-to-hourly-calculator.html', 'labour.gov.in'],
  ['articles/how-to-build-an-emergency-fund.html', 'I%20Can%20Do_RBI.pdf'],
  ['articles/how-to-build-a-realistic-monthly-budget.html', 'FinancialEducation/fame.aspx'],
  ['articles/sip-calculator-with-inflation-and-tax.html', 'incometax.gov.in'],
  ['articles/loan-emi-guide.html', 'Id=12663'],
  ['articles/why-a-lower-emi-can-cost-you-more-overall.html', 'FAQRFIR10012025.pdf'],
  ['articles/how-to-compare-loan-offers-beyond-emi.html', 'Id=12663'],
  ['articles/how-to-use-a-debt-payoff-calculator.html', 'Id=12663']
];
for (const [articlePath, requiredSource] of articleSourceRequirements) {
  const articleFile = path.join(root, articlePath);
  if (!fs.existsSync(articleFile)) errors.push(`Article source audit page missing: ${articlePath}`);
  else if (!read(articleFile).includes(requiredSource)) errors.push(`${articlePath}: expected topic-specific official source ${requiredSource}`);
}

const calculatorUrls = sitemapLocs.filter(url => {
  try {
    const pathname = new URL(url).pathname;
    return calculatorSlugs.has(pathname.replace(/^\//,'').replace(/\/$/,''));
  } catch { return false; }
});
if (calculatorUrls.length !== 55) errors.push(`Expected 55 calculator pages in sitemap, found ${calculatorUrls.length}`);
for (const url of calculatorUrls) {
  const file = repositoryFileForUrl(url);
  if (!file) continue;
  const html = read(file);
  const name = rel(file);
  if (!/wa-calculator-runtime\.js/i.test(html)) errors.push(`${name}: canonical calculator runtime missing`);
  if (/calculators\.js/i.test(html)) errors.push(`${name}: legacy calculators.js runtime reference found`);
  if (!/formula|how it works|assumptions|limitations|estimate/i.test(html)) warnings.push(`${name}: educational/explanatory copy may be too thin`);
}

if (fs.existsSync('wa-calculator-runtime.js') && fs.statSync('wa-calculator-runtime.js').size > 750_000) errors.push('Canonical calculator runtime exceeds 750 KB budget');
if (fs.existsSync('node_modules')) errors.push('node_modules must not be present in the deployable repository');

if (errors.length) {
  console.error(`LAUNCH READINESS FAILED (${errors.length} errors)`);
  errors.forEach(e => console.error(`- ${e}`));
  if (warnings.length) { console.error(`Warnings: ${warnings.length}`); warnings.forEach(w => console.error(`- ${w}`)); }
  process.exit(1);
}
console.log(`LAUNCH READINESS PASS: ${htmlFiles.length} HTML pages, ${calculatorUrls.length} sitemap calculators, sitemap, robots, security headers, canonical runtime and trust assets validated.`);
if (warnings.length) {
  console.log(`Warnings: ${warnings.length}`);
  warnings.forEach(w => console.log(`- ${w}`));
}
