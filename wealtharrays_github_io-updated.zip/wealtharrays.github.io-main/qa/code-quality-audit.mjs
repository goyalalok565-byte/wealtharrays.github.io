import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = process.cwd();
const canonicalSources = ['widget.js','wa-core.js','site-runtime.js','final-polish.js','theme-fix.js','phase3-seo.js','calculator-page-init.js','phase4-premium.js'];
const siteSources = ['wa-core.js','site-runtime.js','final-polish.js','theme-fix.js','phase3-seo.js','phase4-premium.js','calculator-search.js'];
const homeSources = ['final-polish.js','theme-fix.js','phase3-seo.js','phase4-premium.js'];
const supportSources = ['theme-init.js','404-runtime.js'];
const sourceFiles = [...canonicalSources,...supportSources];
for(const file of sourceFiles) if(!fs.existsSync(path.join(root,file))) throw new Error(`Missing source: ${file}`);
const js=sourceFiles.map(file=>({file,text:fs.readFileSync(path.join(root,file),'utf8')}));
const normalize=text=>text.replace(/\/\*[\s\S]*?\*\//g,'').replace(/\/\/[^\n]*/g,'').replace(/\s+/g,' ').trim();
const hashes=new Map();
for(const {file,text} of js){const hash=crypto.createHash('sha256').update(normalize(text)).digest('hex');if(hashes.has(hash)) throw new Error(`Duplicate source module content: ${file} duplicates ${hashes.get(hash)}`);hashes.set(hash,file);}

const calculatorBundle=fs.readFileSync('wa-calculator-runtime.js','utf8');
for(const {file,text} of js.slice(0,canonicalSources.length)){const hash=crypto.createHash('sha256').update(text.replace(/\r\n/g,'\n').trimEnd()).digest('hex').slice(0,12);if(!calculatorBundle.includes(`WA CANONICAL MODULE | calculator | ${file} | sha256:${hash}`)) throw new Error(`Calculator bundle provenance missing/stale for ${file}`);}
const siteBundle=fs.readFileSync('wa-site-runtime.js','utf8');
const homeBundle=fs.readFileSync('wa-home-runtime.js','utf8');
for(const file of siteSources){const text=fs.readFileSync(path.join(root,file),'utf8');const hash=crypto.createHash('sha256').update(text.replace(/\r\n/g,'\n').trimEnd()).digest('hex').slice(0,12);if(!siteBundle.includes(`WA CANONICAL MODULE | site | ${file} | sha256:${hash}`)) throw new Error(`Site bundle provenance missing/stale for ${file}`);}
for(const file of homeSources){const text=fs.readFileSync(path.join(root,file),'utf8');const hash=crypto.createHash('sha256').update(text.replace(/\r\n/g,'\n').trimEnd()).digest('hex').slice(0,12);if(!homeBundle.includes(`WA CANONICAL MODULE | home | ${file} | sha256:${hash}`)) throw new Error(`Home bundle provenance missing/stale for ${file}`);}
const pages=[];
function walkCalculatorPages(dir){
  for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    if(entry.name.startsWith('.')||['node_modules','dist','qa','scripts','calculator-definitions','docs'].includes(entry.name)) continue;
    const file=path.join(dir,entry.name);
    if(entry.isDirectory()) walkCalculatorPages(file);
    else if(entry.name.endsWith('.html')&&entry.name!=='widget.html'){
      const html=fs.readFileSync(file,'utf8');
      const relative=path.relative(root,file).replaceAll(path.sep,'/');
      // This legacy directory is an explicit redirect alias; count only active canonical calculator routes.
      if(relative!=='income-tax-scenario-calculator/index.html'&&/data-wa-calculator=/i.test(html)&&html.includes('wa-calculator-runtime.js')) pages.push(relative);
    }
  }
}
walkCalculatorPages(root);
if(pages.length!==55) throw new Error(`Expected 55 active canonical calculator runtime pages, found ${pages.length}`);
for(const page of pages){const id=fs.readFileSync(path.join(root,page),'utf8').match(/data-wa-calculator="([^"]+)"/i)?.[1];if(!id||!fs.existsSync(path.join(root,'calculator-definitions',`${id}.js`))) throw new Error(`${page}: missing split calculator definition for ${id||'unknown'}`);}
const widget=fs.readFileSync('widget/index.html','utf8');
if(!widget.includes('/calculators.js')||!widget.includes('/wa-calculator-runtime.js')) throw new Error('widget/index.html: calculator bootstrap scripts missing');
if(widget.includes('adsbygoogle.js')||widget.includes('ca-pub-6507600103785450')) throw new Error('widget/index.html: AdSense must not be present');
for(const page of pages){const html=fs.readFileSync(path.join(root,page),'utf8');const srcs=[...html.matchAll(/<script\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi)].map(m=>m[1]);const loadedBasenames=new Set(srcs.map(src=>src.split('?')[0].split('#')[0].split('/').pop()));for(const file of canonicalSources) if(loadedBasenames.has(file)) throw new Error(`${page}: direct calculator runtime dependency ${file}`);}

if(fs.existsSync('calculator-runtime.js')) throw new Error('Retired calculator-runtime.js must not exist');
if(fs.statSync('wa-calculator-runtime.js').size>750_000) throw new Error(`Canonical calculator runtime exceeds 750 KB`);
if(fs.statSync('wa-site-runtime.js').size>750_000) throw new Error(`Canonical site runtime exceeds 750 KB`);
if(fs.statSync('wa-home-runtime.js').size>750_000) throw new Error(`Canonical home runtime exceeds 750 KB`);
if(fs.existsSync('node_modules')) throw new Error('node_modules must not exist in deployable tree');
console.log(`Code-quality audit PASS — ${canonicalSources.length} canonical calculator source modules plus ${supportSources.length} support modules are unique; calculator/site provenance is fresh; calculator-only Phase 2 code is isolated; calculator pages are isolated from direct source dependencies; deploy-tree hygiene is clean.`);
