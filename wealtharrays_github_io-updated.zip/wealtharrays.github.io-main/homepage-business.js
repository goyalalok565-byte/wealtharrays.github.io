(function(){'use strict';
var form=document.getElementById('wa-quick-emi-form');
var grid=document.getElementById('wa-home-tool-grid');
var toggle=document.getElementById('wa-toggle-all-tools');
var search=document.getElementById('tool-search');
var homeCurrency=document.getElementById('currency-select');
if(homeCurrency){
  var homeCurrencies=[["USD","US Dollar","$"],["EUR","Euro","€"],["GBP","British Pound","£"],["INR","Indian Rupee","₹"],["JPY","Japanese Yen","¥"],["CNY","Chinese Yuan","CN¥"],["CAD","Canadian Dollar","C$"],["AUD","Australian Dollar","A$"],["CHF","Swiss Franc","CHF"],["SGD","Singapore Dollar","S$"],["HKD","Hong Kong Dollar","HK$"],["KRW","South Korean Won","₩"],["AED","UAE Dirham","د.إ"],["SAR","Saudi Riyal","﷼"],["NZD","New Zealand Dollar","NZ$"],["MXN","Mexican Peso","MX$"],["BRL","Brazilian Real","R$"],["ZAR","South African Rand","R"],["TRY","Turkish Lira","₺"],["THB","Thai Baht","฿"],["MYR","Malaysian Ringgit","RM"],["IDR","Indonesian Rupiah","Rp"],["PHP","Philippine Peso","₱"],["PLN","Polish Zloty","zł"],["SEK","Swedish Krona","kr"]];
  var savedCurrency=document.documentElement.getAttribute('data-currency')||'INR';
  if(!homeCurrencies.some(function(c){return c[0]===savedCurrency;}))savedCurrency='INR';
  if(!homeCurrency.options.length||!Array.from(homeCurrency.options).some(function(o){return o.value==='INR';})){
    homeCurrency.replaceChildren();
    homeCurrencies.forEach(function(c){var option=document.createElement('option');option.value=c[0];option.textContent=c[1]+' · '+c[2];homeCurrency.appendChild(option);});
  }
  homeCurrency.value=savedCurrency;
  document.documentElement.setAttribute('data-currency',savedCurrency);
  homeCurrency.addEventListener('change',function(){document.documentElement.setAttribute('data-currency',homeCurrency.value||'INR');window.dispatchEvent(new CustomEvent('wa-currency',{detail:{currency:homeCurrency.value||'INR'}}));});
}
if(grid&&toggle){document.documentElement.classList.add('wa-home-ready');var setExpanded=function(expanded){grid.classList.toggle('is-expanded',expanded);toggle.setAttribute('aria-expanded',String(expanded));toggle.textContent=expanded?'Show fewer calculators':'Show all 55 calculators';toggle.hidden=!!(search&&search.value.trim());};toggle.addEventListener('click',function(){setExpanded(!grid.classList.contains('is-expanded'));});if(search){search.addEventListener('input',function(){if(search.value.trim()){grid.classList.add('is-expanded');toggle.hidden=true;}else{setExpanded(false);}});}}
if(!form)return;
var principal=document.getElementById('wa-emi-principal');
var rate=document.getElementById('wa-emi-rate');
var years=document.getElementById('wa-emi-years');
var emiOut=document.getElementById('wa-emi-output');
var interestOut=document.getElementById('wa-emi-interest');
var totalOut=document.getElementById('wa-emi-total');
var currencySelect=document.getElementById('currency-select');
var currencyLabel=document.getElementById('wa-emi-currency-label');
var currencyCode=currencySelect&&currencySelect.value||'INR';
var money=new Intl.NumberFormat('en-IN',{style:'currency',currency:currencyCode,maximumFractionDigits:0});
function updateCurrency(){currencyCode=currencySelect&&currencySelect.value||'INR';money=new Intl.NumberFormat('en-IN',{style:'currency',currency:currencyCode,maximumFractionDigits:0});if(currencyLabel){var option=currencySelect&&currencySelect.options[currencySelect.selectedIndex];var symbol=option&&option.textContent.split(' · ')[1]||currencyCode;currencyLabel.textContent='Loan amount ('+symbol+')';}calculate();}
function calculate(){if(!String(principal.value).trim()||!String(rate.value).trim()||!String(years.value).trim()){form.removeAttribute('aria-invalid');emiOut.textContent='Enter values';interestOut.textContent='—';totalOut.textContent='—';return;}var p=Number(principal.value),annual=Number(rate.value),y=Number(years.value);if(!Number.isFinite(p)||!Number.isFinite(annual)||!Number.isFinite(y)||p<10000||p>100000000||annual<0||annual>40||y<1||y>40){form.setAttribute('aria-invalid','true');emiOut.textContent='Check your inputs';interestOut.textContent='—';totalOut.textContent='—';return;}form.removeAttribute('aria-invalid');var n=Math.round(y*12),r=annual/1200,emi=r===0?p/n:p*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1);if(!Number.isFinite(emi))return;var total=emi*n;emiOut.textContent=money.format(emi);interestOut.textContent=money.format(Math.max(0,total-p));totalOut.textContent=money.format(total);}
form.addEventListener('input',calculate);
form.addEventListener('submit',function(e){e.preventDefault();calculate();});
if(currencySelect)currencySelect.addEventListener('change',updateCurrency);
window.addEventListener('wa-currency',updateCurrency);
updateCurrency();
})();
